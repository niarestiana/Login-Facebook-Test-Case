<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_VisitDate</name>
   <tag></tag>
   <elementGuidId>ef97d6e5-a757-4d42-a22f-a0568b6724d6</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt_visit_date</value>
   </webElementProperties>
</WebElementEntity>
