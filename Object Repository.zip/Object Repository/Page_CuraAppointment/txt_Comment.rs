<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Comment</name>
   <tag></tag>
   <elementGuidId>f297d2ec-3215-40f8-ab08-70b5c85597d5</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt_comment</value>
   </webElementProperties>
</WebElementEntity>
